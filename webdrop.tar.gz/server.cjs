"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = __importDefault(require("express"));
var http_1 = require("http");
var peer_1 = require("peer");
var process_1 = require("process");
var morgan_1 = __importDefault(require("morgan"));
var crypto_1 = require("crypto");
var app = (0, express_1.default)();
var server = (0, http_1.createServer)(app);
var getUserIPRoom = function (req) {
    var ip = '';
    var realIP = req.headers["X-Real-IP"];
    if (!realIP) {
        var forwarded = req.headers['x-forwarded-for'];
        realIP = typeof forwarded === 'string' ? forwarded.split(/, /)[0] : req.socket.remoteAddress;
    }
    if (typeof realIP === "string" && realIP.length > 0) {
        ip = realIP;
    }
    if (!ip) {
        ip = Math.random().toString(36).substring(7);
    }
    var bname = (0, crypto_1.createHash)('md5').update(ip).digest("base64");
    var name = '';
    for (var _i = 0, bname_1 = bname; _i < bname_1.length; _i++) {
        var b = bname_1[_i];
        b = b.toUpperCase();
        switch (b) {
            case '+':
                name += "0";
                break;
            case '/':
                name += "1";
                break;
            case '=':
                name += "2";
                break;
            default:
                name += b;
        }
        if (name.length == 6) {
            break;
        }
    }
    while (name.length != 6) {
        name += "Z";
    }
    return { name: name, ip: ip };
};
app.enable("trust proxy");
app.use((0, morgan_1.default)("short"));
app.use(function (req, res, next) {
    if (req.path === "/") {
        var room = getUserIPRoom(req);
        res.cookie("userip", room.ip, { maxAge: 900000 });
        res.cookie("useriproom", room.name, { maxAge: 900000 });
    }
    return next();
});
var peerServer = (0, peer_1.ExpressPeerServer)(server, {
    path: "/peer",
    proxied: true,
});
var rooms = new Map();
var roomID = /^[A-Z0-9]{6}$/;
function getRoom(id) {
    var parts = id.split("-");
    if (parts.length !== 3) {
        return null;
    }
    if (!roomID.test(parts[0])) {
        return null;
    }
    return parts[0];
}
peerServer.on("connection", function (client) {
    var id = client.getId();
    console.log("connection: ", id);
});
peerServer.on("message", function (client, message) {
    var id = client.getId();
    if (message.type === "HEARTBEAT") {
        var rid = getRoom(client.getId());
        if (!rid) {
            client.send({ type: "ERROR", payload: "Invalid room" });
            return;
        }
        var room = rooms.get(rid);
        if (!room) {
            rooms.set(rid, [{ id: id }]);
            console.log("room created: ", id);
            return;
        }
        var user = room.find(function (u) { return u.id === id; });
        if (!user) {
            room.push({ id: id });
            console.log("user joined: ", id);
            return;
        }
    }
});
peerServer.on("disconnect", function (client) {
    var id = client.getId();
    var ws = client.getSocket();
    console.log("disconnect: ", id, ws === null || ws === void 0 ? void 0 : ws.url);
    var rid = getRoom(client.getId());
    if (rid) {
        var room = rooms.get(rid);
        if (room) {
            var index = room.findIndex(function (u) { return u.id === id; });
            if (index >= 0) {
                room.splice(index, 1);
                console.log("user left: ", id);
            }
            if (room.length === 0) {
                rooms.delete(rid);
                console.log("room deleted: ", rid);
            }
        }
    }
});
peerServer.on("error", function (error) {
    console.log("peerServer error: ", error);
});
app.use("/", peerServer);
app.use("/", express_1.default.static("dist"));
app.use("/api/room/:room/users", function (req, res) {
    var rid = req.params.room;
    if (!rid) {
        res.status(400).send("Invalid room");
        return;
    }
    var room = rooms.get(rid);
    if (!room) {
        res.json([]);
        return;
    }
    res.json(room);
});
var port = process.env.PORT || "8080";
var host = process.env.HOSTNAME || "localhost";
server.listen({
    host: host,
    port: port,
    exclusive: true,
}, function () {
    console.log("Server is running on http://".concat(host, ":").concat(port));
});
server.on("error", function (error) {
    console.log("Error: ", error);
    (0, process_1.exit)(1);
});
